#include <stdio.h>
int main(){

char c = '\n';
printf("jodonn6%c",c);
return 0;
}

void all(){

}
char your[4];

void cs361(){
}
char are='a';
char belong[4];
int to =0;;
char us[37];
